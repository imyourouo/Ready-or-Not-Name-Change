@echo off
chcp 65001 >nul
setlocal
title Ready or Not Rename Tool
set "HERE=%~dp0"
set "PYEXE="
set "PYARG="

if exist "%HERE%python\python.exe" set "PYEXE=%HERE%python\python.exe"
if not defined PYEXE if exist "C:\Users\SAKUYA\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" set "PYEXE=C:\Users\SAKUYA\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if not defined PYEXE (
    where py >nul 2>nul
    if not errorlevel 1 (
        set "PYEXE=py"
        set "PYARG=-3"
    )
)
if not defined PYEXE (
    where python >nul 2>nul
    if not errorlevel 1 set "PYEXE=python"
)
if not defined PYEXE (
    echo.
    echo   Python 3 not found.
    echo   Install Python 3, or put python.exe into a "python" subfolder here.
    echo.
    pause
    exit /b 1
)

"%PYEXE%" %PYARG% "%HERE%rename_tool.py" %*
echo.
pause
