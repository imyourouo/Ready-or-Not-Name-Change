# -*- coding: utf-8 -*-
r"""Ready or Not - rename a character / voice display name (bilingual: zh / en)

How it works (identical to pakchunk99-OperatorTaki_P.pak):
  only the display-name FString inside the customization asset is changed (its length
  field follows), plus the SerialSize of that export. Every other byte is untouched.
  When the name gets shorter, the freed bytes are padded *outside* the export data so
  the file length stays the same and the export data stays a complete property stream.

Usage:
  double-click  改名工具.bat        (Chinese UI)
  double-click  RenameTool_EN.bat   (English UI)
  python rename_tool.py --lang en --list
  python rename_tool.py --from Judge --to Soyo [--install]
  python rename_tool.py --batch pairs.txt [--install]
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import struct
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(HERE, 'config.json')
INDEX_PATH = os.path.join(HERE, 'asset_index.json')
OUT_DIR = HERE                      # generated paks land next to the scripts
DEFAULT_GAME = r'E:\SteamLibrary\steamapps\common\Ready Or Not'
NAME_TAG = b'\xff\x01\x00\x00\x00'  # property tag right before the display-name FString
ASSET_RE = re.compile(
    r'^ReadyOrNot/Content/Blueprints/Customization/(Characters|Voices)/([^/]+)\.(uasset|uexp)$')

LANG = 'zh'


def _load_lang(argv):
    global LANG
    val = os.environ.get('RONTOOL_LANG', '')
    for i, a in enumerate(argv):
        if a == '--lang' and i + 1 < len(argv):
            val = argv[i + 1]
        elif a.startswith('--lang='):
            val = a.split('=', 1)[1]
    LANG = 'en' if str(val).lower().startswith('en') else 'zh'


M = {
    'zh': {
        'title': ' Ready Or Not 角色 / 语音 改名工具',
        'game': ' 游戏目录：%s',
        'outdir': ' 输出目录：%s',
        'm1': '  1) 列出可改名的角色与语音',
        'm2': '  2) 改名（生成 pak，可选装入游戏）',
        'm3': '  3) 批量改名（每行：旧名=新名）',
        'm4': '  4) 重新扫描游戏包（游戏更新后用）',
        'm5': '  5) 打开输出目录',
        'm6': '  6) 修改游戏目录（换了电脑 / 换了安装位置）',
        'm0': '  0) 退出',
        'select': '\n请选择：',
        'scanning': '正在扫描游戏包（第一次稍慢，约 20 秒）...',
        'scanned': '扫描完成，共 %d 个资产。',
        'assetline': '  %-34s 显示名：%s',
        'unknown': '（未识别）',
        'kind_char': '角色',
        'kind_voice': '语音',
        'list_head': '%-36s %-8s %s',
        'list_cols': ('资产名', '类型', '当前显示名'),
        'no_asset': '!! 没有找到显示名为 "%s" 的资产。用"列出"功能看看有哪些可改名项。',
        'too_long': '!! 新名字太长（上限 40 个字符）。',
        'not_ascii': '!! 目前只支持英文/数字/符号的新名字（这里写的是 "%s"）。',
        'readback': '%s 回读校验失败（读到 %r）',
        'generated': '已生成：%s',
        'size_sha': '  大小 %d 字节   sha256 %s',
        'built_line': '  %-30s 显示名 %s -> %s（导出大小变化 %+d 字节）',
        'verify': '  解包复核：%s',
        'verify_ok': '通过',
        'verify_bad': '失败！',
        'installed': '  已装入游戏：%s',
        'uninstall': '  想撤销就删掉这个 pak 文件即可。',
        'others': '  提示：Paks 目录里还有这些模组包（如果它们也改同一个角色，记得只留一个）：',
        'ask_who': '要改的是谁？（显示名或资产名，例如 Judge / CC_Judge）：',
        'ask_new': '改成什么名字？（英文/数字）：',
        'ask_install': '生成后直接装进游戏吗？(y/N)：',
        'empty_name': '!! 名字不能为空',
        'batch_hint': '每行写一条：旧名=新名，空行结束。',
        'batch_prompt': '> ',
        'batch_install': '全部生成后直接装进游戏吗？(y/N)：',
        'batch_skip': '!! 跳过（格式不对）：%s',
        'need_repak': '!! 找不到 repak.exe，请把它放在本工具目录下。',
        'need_game': '!! 没找到游戏目录。用 --game "游戏根目录" 指定一次，之后会记住。',
        'g_none': '没自动找到游戏目录（第一次在其他电脑上运行时会这样）。',
        'g_how': '请把游戏根目录粘进来——就是能看到 ReadyOrNot 文件夹的那一层，',
        'g_eg': '比如：  D:\\SteamLibrary\\steamapps\\common\\Ready Or Not',
        'g_drag': '（在资源管理器里把那个文件夹拖进这个窗口也可以）',
        'g_prompt': '游戏根目录：',
        'g_saved': '已记住：%s',
        'g_bad': '这个目录不对（里面要有 ReadyOrNot\\Content\\Paks\\pakchunk0-Windows.pak）。',
        'g_new': '新的游戏根目录（能看到 ReadyOrNot 文件夹的那一层）：',
        'g_updated': '已更新并重新扫描，共 %d 个资产。',
        'g_bad2': '!! 这个目录不对：里面要有 ReadyOrNot\\Content\\Paks\\pakchunk0-Windows.pak',
        'sep': '-' * 60,
    },
    'en': {
        'title': ' Ready or Not - Character / Voice Rename Tool',
        'game': ' Game folder: %s',
        'outdir': ' Output folder: %s',
        'm1': '  1) List renamable characters and voices',
        'm2': '  2) Rename (build a pak, optionally install)',
        'm3': '  3) Batch rename (one OLD=NEW per line)',
        'm4': '  4) Rescan game paks (after a game update)',
        'm5': '  5) Open output folder',
        'm6': '  6) Change game folder (moved PC / moved game)',
        'm0': '  0) Quit',
        'select': '\nSelect: ',
        'scanning': 'Scanning game paks (first run takes ~20s)...',
        'scanned': 'Scan complete: %d assets.',
        'assetline': '  %-34s display name: %s',
        'unknown': '(unknown)',
        'kind_char': 'Character',
        'kind_voice': 'Voice',
        'list_head': '%-36s %-10s %s',
        'list_cols': ('Asset', 'Kind', 'Current display name'),
        'no_asset': '!! No asset with display name "%s". Use option 1 to see the list.',
        'too_long': '!! Name too long (max 40 characters).',
        'not_ascii': '!! Only ASCII letters/digits/symbols are supported (got "%s").',
        'readback': '%s read-back check failed (got %r)',
        'generated': 'Generated: %s',
        'size_sha': '  size %d bytes   sha256 %s',
        'built_line': '  %-30s display name %s -> %s (export size %+d bytes)',
        'verify': '  unpack verify: %s',
        'verify_ok': 'PASS',
        'verify_bad': 'FAILED',
        'installed': '  Installed into game: %s',
        'uninstall': '  To uninstall, just delete that pak file.',
        'others': '  Note: other mod paks found (keep only one that touches the same character):',
        'ask_who': 'Which one? (display name or asset name, e.g. Judge / CC_Judge): ',
        'ask_new': 'New name (ASCII): ',
        'ask_install': 'Install into the game after building? (y/N): ',
        'empty_name': '!! Name cannot be empty',
        'batch_hint': 'One entry per line: OLD=NEW  (empty line to finish).',
        'batch_prompt': '> ',
        'batch_install': 'Install all after building? (y/N): ',
        'batch_skip': '!! Skipped (bad format): %s',
        'need_repak': '!! repak.exe not found. Put it next to this script.',
        'need_game': '!! Game folder not found. Run once with --game "path to Ready Or Not".',
        'g_none': 'Game folder not found automatically (normal on a new PC).',
        'g_how': 'Paste the game root folder - the one that contains the ReadyOrNot folder,',
        'g_eg': 'e.g.   D:\\SteamLibrary\\steamapps\\common\\Ready Or Not',
        'g_drag': '(you can also drag that folder into this window)',
        'g_prompt': 'Game root folder: ',
        'g_saved': 'Saved: %s',
        'g_bad': 'Wrong folder (it must contain ReadyOrNot\\Content\\Paks\\pakchunk0-Windows.pak).',
        'g_new': 'New game root folder (the one containing ReadyOrNot): ',
        'g_updated': 'Updated and rescanned: %d assets.',
        'g_bad2': '!! Wrong folder: it must contain ReadyOrNot\\Content\\Paks\\pakchunk0-Windows.pak',
        'sep': '-' * 60,
    },
}


def t(key, *args):
    table = M.get(LANG, M['zh'])
    s = table.get(key) or M['zh'].get(key) or key
    return s % args if args else s


def out(msg=''):
    print(msg, flush=True)


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def load_config():
    cfg = {'game_dir': DEFAULT_GAME, 'repak': None, 'lang': None}
    if os.path.isfile(CONFIG_PATH):
        try:
            cfg.update(json.load(open(CONFIG_PATH, encoding='utf-8')))
        except Exception:
            pass
    if not cfg.get('repak') or not os.path.isfile(cfg['repak']):
        for cand in (os.path.join(HERE, 'repak.exe'), r'E:\CodexWork\tools\repak.exe'):
            if os.path.isfile(cand):
                cfg['repak'] = cand
                break
    return cfg


def save_config(cfg):
    json.dump(cfg, open(CONFIG_PATH, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)


def game_ok(path):
    """True if this folder is the game root (contains ReadyOrNot\\Content\\Paks\\pakchunk0-*.pak)."""
    if not path:
        return False
    return os.path.isfile(os.path.join(path, 'ReadyOrNot', 'Content', 'Paks',
                                       'pakchunk0-Windows.pak'))


def _steam_roots():
    roots = []
    try:
        import winreg
        for hive, key in ((winreg.HKEY_CURRENT_USER, r'Software\Valve\Steam'),
                          (winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\WOW6432Node\Valve\Steam')):
            try:
                with winreg.OpenKey(hive, key) as k:
                    for name in ('SteamPath', 'InstallPath'):
                        try:
                            roots.append(winreg.QueryValueEx(k, name)[0])
                        except OSError:
                            pass
            except OSError:
                pass
    except ImportError:
        pass
    return roots


def _library_dirs(steam_root):
    out_dirs = [steam_root]
    for vdf in (os.path.join(steam_root, 'steamapps', 'libraryfolders.vdf'),
                os.path.join(steam_root, 'config', 'libraryfolders.vdf')):
        if not os.path.isfile(vdf):
            continue
        try:
            text = open(vdf, encoding='utf-8', errors='replace').read()
        except OSError:
            continue
        out_dirs += [m.replace('\\\\', '\\') for m in re.findall(r'"path"\s+"([^"]+)"', text)]
    return out_dirs


def candidate_game_dirs(cfg):
    cands = [cfg.get('game_dir')]
    for root in _steam_roots():
        for lib in _library_dirs(root):
            cands.append(os.path.join(lib, 'steamapps', 'common', 'Ready Or Not'))
    for drive in 'CDEFGH':
        cands.append(r'%s:\SteamLibrary\steamapps\common\Ready Or Not' % drive)
        cands.append(r'%s:\Steam\steamapps\common\Ready Or Not' % drive)
        cands.append(r'%s:\Program Files (x86)\Steam\steamapps\common\Ready Or Not' % drive)
        cands.append(r'%s:\Program Files\Steam\steamapps\common\Ready Or Not' % drive)
        cands.append(r'%s:\Program Files\Epic Games\ReadyOrNot' % drive)
        cands.append(r'%s:\Games\Ready Or Not' % drive)
    seen, result = set(), []
    for c in cands:
        if not c:
            continue
        c = os.path.normpath(c)
        if c.lower() in seen:
            continue
        seen.add(c.lower())
        result.append(c)
    return result


def find_game(cfg, interactive=True):
    for c in candidate_game_dirs(cfg):
        if game_ok(c):
            if os.path.normpath(c) != os.path.normpath(cfg.get('game_dir') or ''):
                cfg['game_dir'] = c
                save_config(cfg)
            return c
    if not interactive:
        return None
    out('')
    out(t('g_none'))
    out(t('g_how'))
    out(t('g_eg'))
    out(t('g_drag'))
    for _ in range(3):
        try:
            p = input(t('g_prompt')).strip().strip('"').strip("'")
        except (EOFError, KeyboardInterrupt):
            return None
        if p and game_ok(p):
            cfg['game_dir'] = os.path.normpath(p)
            save_config(cfg)
            out(t('g_saved', cfg['game_dir']))
            return cfg['game_dir']
        out(t('g_bad'))
    return None


class Repak:
    def __init__(self, exe):
        self.exe = exe

    def _run(self, args, binary=False):
        r = subprocess.run([self.exe] + args, capture_output=True)
        if r.returncode != 0:
            raise RuntimeError('repak %s failed: %s'
                               % (' '.join(args[:2]),
                                  r.stderr.decode('utf-8', 'replace')[:300]))
        return r.stdout if binary else r.stdout.decode('utf-8', 'replace')

    def list(self, pak):
        return [l.strip() for l in self._run(['list', pak]).splitlines() if l.strip()]

    def get(self, pak, path):
        return self._run(['get', pak, path], binary=True)

    def pack(self, folder, dest):
        args = ['pack', folder, '-q', '--version', 'V11', '--compression', 'Oodle', '-p', '0']
        r = subprocess.run([self.exe] + args, capture_output=True)
        produced = folder + '.pak'
        if not os.path.isfile(produced):
            raise RuntimeError('pack failed: %s' % r.stderr.decode('utf-8', 'replace')[:300])
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.move(produced, dest)
        return dest


def read_fstring(d, o):
    n = struct.unpack_from('<i', d, o)[0]
    if n <= 0:
        return '', o + 4
    return d[o + 4:o + 4 + n - 1].decode('ascii', 'replace'), o + 4 + n


def parse_asset(uasset, uexp):
    u = bytearray(uasset)
    e = bytearray(uexp)
    o = 0x1C + struct.unpack_from('<i', u, 0x18)[0] * 20
    ths = struct.unpack_from('<i', u, o)[0]
    o += 4
    _, o = read_fstring(u, o)
    ec, eo = struct.unpack_from('<ii', u, o + 28)
    ex = []
    for i in range(ec):
        b = eo + i * 96
        size, off = struct.unpack_from('<qq', u, b + 28)
        ex.append(dict(rec=b, size=size, off=off))
    return u, e, ths, ex


def display_name(uexp, uasset):
    u, e, ths, ex = parse_asset(uasset, uexp)
    for x in ex:
        data = bytes(e[x['off'] - ths:x['off'] - ths + x['size']])
        i = data.find(NAME_TAG)
        if i < 0:
            continue
        s, _ = read_fstring(data, i + len(NAME_TAG))
        if s and all(32 <= ord(c) < 127 for c in s):
            return s
    return None


def patch_asset(uasset, uexp, new_name):
    u, e, ths, ex = parse_asset(uasset, uexp)
    nb = new_name.encode('ascii')
    for x in sorted(ex, key=lambda y: y['off']):
        pos = x['off'] - ths
        old_export = bytes(e[pos:pos + x['size']])
        i = old_export.find(NAME_TAG)
        if i < 0:
            continue
        old_name, _ = read_fstring(old_export, i + len(NAME_TAG))
        if not old_name:
            continue
        str_pos = i + len(NAME_TAG)
        old_bytes = struct.pack('<i', len(old_name.encode()) + 1) + old_name.encode() + b'\x00'
        new_bytes = struct.pack('<i', len(nb) + 1) + nb + b'\x00'
        new_export = old_export[:str_pos] + new_bytes + old_export[str_pos + len(old_bytes):]
        delta = len(new_export) - len(old_export)
        tail = bytes(e[pos + x['size']:])
        pad = b'\x00' * (-delta) if delta < 0 else b''
        e2 = bytes(e[:pos]) + new_export + pad + tail
        struct.pack_into('<q', u, x['rec'] + 28, x['size'] + delta)
        for y in ex:
            if y['off'] > x['off']:
                struct.pack_into('<q', u, y['rec'] + 36, y['off'] + delta)
        return bytes(u), e2, old_name, delta
    raise RuntimeError('display-name field not found in these assets')


def scan(cfg, repak, force=False):
    paks_dir = os.path.join(cfg['game_dir'], 'ReadyOrNot', 'Content', 'Paks')
    paks = sorted(x for x in os.listdir(paks_dir)
                  if re.match(r'^pakchunk.*\.pak$', x) and 'Windows.pak' in x)
    stamp = '|'.join('%s:%d' % (p, os.path.getsize(os.path.join(paks_dir, p)))
                     for p in paks)
    if not force and os.path.isfile(INDEX_PATH):
        try:
            idx = json.load(open(INDEX_PATH, encoding='utf-8'))
            if idx.get('stamp') == stamp:
                return idx
        except Exception:
            pass
    out(t('scanning'))
    index = {'stamp': stamp, 'assets': {}}
    for p in paks:
        pak_path = os.path.join(paks_dir, p)
        entries = repak.list(pak_path)
        groups = {}
        for path in entries:
            m = ASSET_RE.match(path)
            if m:
                groups.setdefault((m.group(1), m.group(2)), {})[m.group(3)] = path
        for (kind, name), files in groups.items():
            if 'uasset' not in files or 'uexp' not in files:
                continue
            if name in index['assets']:
                continue
            try:
                ua = repak.get(pak_path, files['uasset'])
                ux = repak.get(pak_path, files['uexp'])
                dn = display_name(ux, ua)
            except Exception:
                dn = None
            index['assets'][name] = {'pak': p, 'kind': kind, 'display': dn,
                                     'uasset': files['uasset'], 'uexp': files['uexp']}
            out(t('assetline', name, dn or t('unknown')))
    json.dump(index, open(INDEX_PATH, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    return index


def group_by_display(index, key):
    assets = index['assets']
    if key in assets:
        return [key]
    return sorted(n for n, v in assets.items()
                  if (v.get('display') or '').lower() == key.lower())


def build(cfg, repak, index, old_key, new_name, install=False, quiet=False):
    paks_dir = os.path.join(cfg['game_dir'], 'ReadyOrNot', 'Content', 'Paks')
    targets = group_by_display(index, old_key)
    if not targets:
        out(t('no_asset', old_key))
        return None
    if len(new_name) > 40:
        out(t('too_long'))
        return None
    try:
        new_name.encode('ascii')
    except UnicodeEncodeError:
        out(t('not_ascii', new_name))
        return None
    safe = re.sub(r'[^A-Za-z0-9_\-]+', '', new_name) or 'Name'
    stage = os.path.join(HERE, '_stage')
    if os.path.isdir(stage):
        shutil.rmtree(stage)
    rows = []
    for name in targets:
        info = index['assets'][name]
        pak_path = os.path.join(paks_dir, info['pak'])
        ua = repak.get(pak_path, info['uasset'])
        ux = repak.get(pak_path, info['uexp'])
        ua2, ux2, old_name, delta = patch_asset(ua, ux, new_name)
        chk = display_name(ux2, ua2)
        if chk != new_name:
            raise RuntimeError(t('readback', name, chk))
        dst = os.path.join(stage, os.path.dirname(info['uasset']))
        os.makedirs(dst, exist_ok=True)
        open(os.path.join(stage, info['uasset']), 'wb').write(ua2)
        open(os.path.join(stage, info['uexp']), 'wb').write(ux2)
        rows.append((name, old_name, new_name, delta))
    pak_name = 'pakchunk99-%sName_P.pak' % safe
    out_pak = os.path.join(OUT_DIR, pak_name)
    repak.pack(stage, out_pak)
    check_dir = os.path.join(HERE, '_verify')
    if os.path.isdir(check_dir):
        shutil.rmtree(check_dir)
    os.makedirs(check_dir)
    subprocess.run([repak.exe, 'unpack', out_pak, '-o', check_dir, '-q'], capture_output=True)
    ok = True
    for name in targets:
        info = index['assets'][name]
        p = os.path.join(check_dir, info['uexp'])
        if not os.path.isfile(p):
            ok = False
            continue
        ua = open(os.path.join(check_dir, info['uasset']), 'rb').read()
        ux = open(p, 'rb').read()
        if display_name(ux, ua) != new_name:
            ok = False
    if not quiet:
        out('')
        out(t('generated', out_pak))
        out(t('size_sha', os.path.getsize(out_pak), sha256_of(out_pak)))
        for name, old_name, new2, delta in rows:
            out(t('built_line', name, old_name, new2, delta))
        out(t('verify', t('verify_ok') if ok else t('verify_bad')))
    if not ok:
        return None
    shutil.rmtree(stage, ignore_errors=True)
    shutil.rmtree(check_dir, ignore_errors=True)
    if install:
        dst = os.path.join(paks_dir, pak_name)
        shutil.copy2(out_pak, dst)
        if not quiet:
            out(t('installed', dst))
            out(t('uninstall'))
            others = [p for p in os.listdir(paks_dir)
                      if p.endswith('.pak') and p != pak_name and 'Windows' not in p
                      and re.match(r'^pakchunk.*\.pak$', p)]
            if others:
                out('')
                out(t('others'))
                for p in others[:12]:
                    out('     %s' % p)
    return out_pak


def menu(cfg, repak, index):
    while True:
        out('')
        out('=' * 60)
        out(t('title'))
        out(t('game', cfg['game_dir']))
        out(t('outdir', OUT_DIR))
        out('=' * 60)
        for k in ('m1', 'm2', 'm3', 'm4', 'm5', 'm6', 'm0'):
            out(t(k))
        try:
            choice = input(t('select')).strip()
        except (EOFError, KeyboardInterrupt):
            out('')
            return
        if choice == '0':
            return
        if choice == '1':
            out('')
            cols = t('list_cols')
            out(t('list_head', *cols))
            out(t('sep'))
            for name in sorted(index['assets']):
                v = index['assets'][name]
                out(t('list_head', name,
                      t('kind_char') if v['kind'] == 'Characters' else t('kind_voice'),
                      v.get('display') or t('unknown')))
        elif choice == '2':
            try:
                key = input(t('ask_who')).strip()
                new = input(t('ask_new')).strip()
                if not key or not new:
                    out(t('empty_name'))
                    continue
                ans = input(t('ask_install')).strip().lower()
            except (EOFError, KeyboardInterrupt):
                out('')
                continue
            build(cfg, repak, index, key, new, install=(ans == 'y'))
        elif choice == '3':
            out(t('batch_hint'))
            lines = []
            while True:
                try:
                    line = input(t('batch_prompt')).strip()
                except (EOFError, KeyboardInterrupt):
                    break
                if not line:
                    break
                lines.append(line)
            try:
                ans = input(t('batch_install')).strip().lower()
            except (EOFError, KeyboardInterrupt):
                ans = 'n'
            for line in lines:
                if '=' not in line:
                    out(t('batch_skip', line))
                    continue
                old, new = [x.strip() for x in line.split('=', 1)]
                out('')
                out('--- %s -> %s' % (old, new))
                build(cfg, repak, index, old, new, install=(ans == 'y'))
        elif choice == '4':
            index = scan(cfg, repak, force=True)
            out(t('scanned', len(index['assets'])))
        elif choice == '5':
            os.makedirs(OUT_DIR, exist_ok=True)
            os.startfile(OUT_DIR)
        elif choice == '6':
            try:
                p = input(t('g_new')).strip().strip('"').strip("'")
            except (EOFError, KeyboardInterrupt):
                out('')
                continue
            if game_ok(p):
                cfg['game_dir'] = os.path.normpath(p)
                save_config(cfg)
                index = scan(cfg, repak, force=True)
                out(t('g_updated', len(index['assets'])))
            else:
                out(t('g_bad2'))


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    _load_lang(sys.argv[1:])
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument('--lang', choices=['zh', 'en'])
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--from', dest='old')
    ap.add_argument('--to', dest='new')
    ap.add_argument('--batch')
    ap.add_argument('--install', action='store_true')
    ap.add_argument('--rescan', action='store_true')
    ap.add_argument('--game')
    a = ap.parse_args()
    cfg = load_config()
    if a.game:
        cfg['game_dir'] = os.path.normpath(a.game) if game_ok(a.game) else a.game
        save_config(cfg)
    if not cfg.get('repak'):
        out(t('need_repak'))
        return 1
    repak = Repak(cfg['repak'])
    gdir = find_game(cfg, interactive=not (a.list or a.old or a.batch))
    if not gdir:
        out(t('need_game'))
        return 1
    os.makedirs(OUT_DIR, exist_ok=True)
    index = scan(cfg, repak, force=a.rescan)
    if a.list:
        cols = t('list_cols')
        out(t('list_head', *cols))
        for name in sorted(index['assets']):
            v = index['assets'][name]
            out(t('list_head', name,
                  t('kind_char') if v['kind'] == 'Characters' else t('kind_voice'),
                  v.get('display') or t('unknown')))
        return 0
    if a.batch:
        for line in open(a.batch, encoding='utf-8'):
            line = line.strip()
            if not line or '=' not in line:
                continue
            old, new = [x.strip() for x in line.split('=', 1)]
            out('')
            out('--- %s -> %s' % (old, new))
            build(cfg, repak, index, old, new, install=a.install)
        return 0
    if a.old and a.new:
        return 0 if build(cfg, repak, index, a.old, a.new, install=a.install) else 2
    menu(cfg, repak, index)
    return 0


if __name__ == '__main__':
    sys.exit(main())
