Ready or Not - Character / Voice Rename Tool (English UI)
=========================================================

What it does
  Renames the display name of a character and/or voice in the customization menu.
  The name also shows up as the speaker name in subtitles.

How to use
  1. Double-click  RenameTool_EN.bat
  2. Choose 2
  3. Type the current name (e.g. Judge) or an asset name (e.g. CC_Judge)
  4. Type the new name (ASCII letters/digits/symbols, max 40 chars)
  5. Answer y to install into the game, or n to keep the pak next to this script

Menu
  1  List every renamable character / voice with its current display name
  2  Rename one (by display name or asset name)
  3  Batch rename: one OLD=NEW per line
  4  Rescan game paks (after a Steam update)
  5  Open this folder (generated paks are written here)
  6  Change the game folder (new PC / moved install)

Command line
  RenameTool_EN.bat --list
  RenameTool_EN.bat --from Judge --to Soyo --install
  RenameTool_EN.bat --batch list.txt --install
  RenameTool_EN.bat --game "D:\SteamLibrary\steamapps\common\Ready Or Not"

Portable
  The folder ships its own Python 3.12 and repak.exe, so nothing has to be installed.
  The game folder is auto-detected (Steam registry + library folders + common drives).
  If it is not found, the tool asks once and remembers it in config.json.

How it works
  Only the display-name FString inside Characters/CC_*.uasset|uexp and
  Voices/CV_*.uasset|uexp is rewritten, together with that export's SerialSize.
  Every other byte stays identical to the game original; when the name gets shorter
  the freed bytes are padded outside the export data, so the asset stays valid.

Notes
  * Generated paks are named pakchunk99-<Name>Name_P.pak.
  * To uninstall, delete that pak from ReadyOrNot\Content\Paks.
  * Assets keep their internal names (CC_Judge stays CC_Judge); only the shown name changes.
